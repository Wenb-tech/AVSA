import torch
from torch import nn


class CrossEntropyWithLabelSmooth(nn.Module):
    """ Cross entropy loss with label smoothing regularization.

    Reference:
        Szegedy et al. Rethinking the Inception Architecture for Computer Vision. In CVPR, 2016.
    Equation: 
        y = (1 - epsilon) * y + epsilon / K.

    Args:
        epsilon (float): a hyper-parameter in the above equation.
    """
    def __init__(self, epsilon=0.1):
        super().__init__()
        self.epsilon = epsilon
        self.logsoftmax = nn.LogSoftmax(dim=1)

    def forward(self, inputs, targets):
        """
        Args:
            inputs: prediction matrix (before softmax) with shape (batch_size, num_classes)
            targets: ground truth labels with shape (batch_size)
        """
        batch_size, num_classes = inputs.size()
        log_probs = self.logsoftmax(inputs)
        
        # 优化：直接在 GPU 上创建 one-hot 向量，避免 CPU-GPU 数据传输
        targets_one_hot = torch.zeros_like(log_probs).scatter_(1, targets.unsqueeze(1), 1)
        
        # 应用标签平滑
        targets_smooth = (1 - self.epsilon) * targets_one_hot + self.epsilon / num_classes
        
        # 计算损失
        loss = (- targets_smooth * log_probs).mean(0).sum()

        return loss
