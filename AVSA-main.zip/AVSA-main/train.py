import time
import datetime
import logging
import torch
torch.autograd.set_detect_anomaly(True)
from apex import amp
from tools.utils import AverageMeter
from losses.triplet_loss import TripletLoss
import torch.nn as nn
import torch.nn.functional as F  


def train_cal(config, epoch, model, vib, feat_aug, classifier, model_aug, clothes_classifier, criterion_cla, criterion_pair,
              criterion_clothes, criterion_adv, optimizer, optimizer_cc, trainloader, pid2clothes):
    logger = logging.getLogger('reid.train')
    # 初始化损失记录器（保持不变）
    batch_original_cla_loss = AverageMeter()
    batch_original_tri_loss = AverageMeter()
    batch_recon_cla_loss = AverageMeter()
    batch_kl_loss = AverageMeter()
    # batch_kl_feat_loss = AverageMeter()  # 新增：原始特征与域增强特征的 KL 散度
    batch_aug_tri_loss = AverageMeter()
    batch_aug_original_tri_loss = AverageMeter()
    corrects = AverageMeter()
    clothes_corrects = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    model.train()
    classifier.train()
    clothes_classifier.train()
    vib.train()
    feat_aug.train()

    criterion_tri = TripletLoss(margin=config.LOSS.PAIR_M)

    end = time.time()
    for batch_idx, batch_data in enumerate(trainloader):
        # 获取所有正样本衣物类别
        # 根据数据类型处理不同的输入格式
        if len(batch_data) == 5:  # 图像数据格式：img, [img1,img2,img3,img4], pid, camid, clothes_id
            imgs, aug_imgs, pids, camids, clothes_ids = batch_data
        else:  # 视频数据格式：clip, pid, camid, clothes_id
            imgs, pids, camids, clothes_ids = batch_data
            aug_imgs = None  # 视频数据暂时不支持aug_imgs
        pos_mask = pid2clothes[pids]
        imgs, pids, clothes_ids, pos_mask = imgs.cuda(), pids.cuda(), clothes_ids.cuda(), pos_mask.float().cuda()
        # 测量数据加载时间
        data_time.update(time.time() - end)

        # 前向传播
        # 根据模型类型处理不同的前向传播
        if hasattr(model.module, 'base'):  # 图像模型
            x = model.module.base(imgs)
            original_feats = model.module.globalpooling(x).view(x.size(0), -1)
            original_feats = model.module.bn(original_feats)
        else:  # 视频模型
            original_feats = model(imgs)

        # 使用 VIB 进行域增强
        recon_feats, mu, logvar = vib(original_feats)  # recon_feats 形状应与 original_feats 一致（[batch_size, feat_dim]）

        # 验证维度是否一致（可选，调试时使用）
        assert original_feats.shape == recon_feats.shape, \
            f"维度不匹配：original_feats {original_feats.shape} vs recon_feats {recon_feats.shape}"

        # kl_feat_loss = kl_divergence(original_feats, recon_feats)  # 计算 KL 散度

        # 特征增强
        vib_generated_feats = recon_feats  # 关键修正：定义 vib_generated_feats 为完整的重构特征
        augmented_original_feats, augmented_vib_feats = feat_aug(original_feats, vib_generated_feats)

        outputs = classifier(original_feats)

        # 处理aug_imgs（仅图像数据）
        if aug_imgs is not None:
            model_state_dict = model.module.state_dict()
            model_aug.load_state_dict(model_state_dict)
            ref_feats = ref(model_aug, aug_imgs)

        pred_clothes = clothes_classifier(original_feats.detach())
        _, preds = torch.max(outputs.data, 1)

        # 更新衣物判别器
        clothes_loss = criterion_clothes(pred_clothes, clothes_ids)
        if epoch >= config.TRAIN.START_EPOCH_CC:
            optimizer_cc.zero_grad()
            if config.TRAIN.AMP:
                with amp.scale_loss(clothes_loss, optimizer_cc) as scaled_loss:
                    scaled_loss.backward()
            else:
                clothes_loss.backward()
            optimizer_cc.step()

        # 更新主干网络
        new_pred_clothes = clothes_classifier(original_feats)
        _, clothes_preds = torch.max(new_pred_clothes.data, 1)

        # 原始特征身份损失
        loss_original_cla = criterion_cla(outputs, pids)
        # 原始特征三元损失
        loss_original_tri = criterion_tri(original_feats, pids)
        # 域特征身份损失
        outputs_recon = classifier(augmented_original_feats)
        loss_recon_cla = criterion_cla(outputs_recon, pids)
        # KL 散度（VIB 隐变量）
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / mu.size(0)
        # 原始特征增强后的三元损失
        loss_aug_original_tri = criterion_tri(augmented_original_feats, pids)
        # 特征增强的三元损失
        loss_aug_tri = criterion_tri(augmented_vib_feats, pids)  # 直接对整体增强特征计算三元损失
        
        # 总损失
        total_loss = (
            1.5 * loss_original_cla          
            + 1.0 * loss_original_tri        
            + 1.0 * loss_recon_cla           
            + 0.3 * kl_loss
            + 0.8 * loss_aug_tri
            + 0.5 * loss_aug_original_tri
        )

        optimizer.zero_grad()
        if config.TRAIN.AMP:
            with amp.scale_loss(total_loss, optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            total_loss.backward()
        optimizer.step()

        # 统计
        corrects.update(torch.sum(preds == pids.data).float() / pids.size(0), pids.size(0))
        clothes_corrects.update(torch.sum(clothes_preds == clothes_ids.data).float() / clothes_ids.size(0), clothes_ids.size(0))
        batch_original_cla_loss.update(loss_original_cla.item(), pids.size(0))
        batch_original_tri_loss.update(loss_original_tri.item(), pids.size(0))
        batch_recon_cla_loss.update(loss_recon_cla.item(), pids.size(0))
        batch_kl_loss.update(kl_loss.item(), pids.size(0))
        batch_aug_tri_loss.update(loss_aug_tri.item(), pids.size(0))
        batch_aug_original_tri_loss.update(loss_aug_original_tri.item(), pids.size(0))
        # 统计（新增 kl_feat_loss 记录，移至循环内）
        # batch_kl_feat_loss.update(kl_feat_loss.item(), pids.size(0))  # 关键修正：在每个 batch 内更新
        # 测量耗时
        batch_time.update(time.time() - end)
        end = time.time()
        # 在每次 backward() 之后添加
        # 在每个批次处理后添加（大约在第150行附近）
        if torch.cuda.is_available():
            # 删除大型临时变量
            del original_feats, recon_feats, augmented_original_feats, augmented_vib_feats
            del outputs, outputs_recon
            if 'x' in locals():
                del x
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
    
    
    # 日志输出
    logger.info('Epoch{0} '
    'Time:{batch_time.sum:.1f}s '
    'Data:{data_time.sum:.1f}s '
    'OriginalClaLoss:{original_cla_loss.avg:.4f} '
    'OriginalTriLoss:{original_tri_loss.avg:.4f} '
    'ReconClaLoss:{recon_cla_loss.avg:.4f} '
    'KLLoss:{kl_loss.avg:.4f} '          # VIB 隐变量 KL 散度
    # 'KLLossFeat:{kl_feat_loss.avg:.4f} '  # 新增：原始特征与域增强特征的 KL 散度
    'AugTriLoss:{aug_tri_loss.avg:.4f} '
    'AugOriginalTriLoss:{aug_original_tri_loss.avg:.4f} '
    'Acc:{acc.avg:.2%} '
    'CloAcc:{clo_acc.avg:.2%} '.format(
    epoch + 1,
    batch_time=batch_time,
    data_time=data_time,
    original_cla_loss=batch_original_cla_loss,
    original_tri_loss=batch_original_tri_loss,
    recon_cla_loss=batch_recon_cla_loss,
    kl_loss=batch_kl_loss,
    aug_tri_loss=batch_aug_tri_loss,
    aug_original_tri_loss=batch_aug_original_tri_loss,
    acc=corrects,
    clo_acc=clothes_corrects
    ))


def ref(model, img_list):
    feats = []

    with torch.no_grad():
        for imgs in img_list:
            x = model.base(imgs.cuda())
            features = model.globalpooling(x).view(x.size(0), -1)
            feats.append(features)

    return feats


def train_cal_with_memory(config, epoch, model, classifier, criterion_cla, criterion_pair,
                          criterion_adv, optimizer, trainloader, pid2clothes):
    logger = logging.getLogger('reid.train')
    batch_cla_loss = AverageMeter()
    batch_pair_loss = AverageMeter()
    batch_adv_loss = AverageMeter()
    corrects = AverageMeter()
    batch_time = AverageMeter()
    data_time = AverageMeter()

    model.train()
    classifier.train()

    end = time.time()
    for batch_idx, (imgs, pids, camids, clothes_ids) in enumerate(trainloader):
        # 获取所有正样本衣物类别
        pos_mask = pid2clothes[pids]
        imgs, pids, clothes_ids, pos_mask = imgs.cuda(), pids.cuda(), clothes_ids.cuda(), pos_mask.float().cuda()
        # 测量数据加载时间
        data_time.update(time.time() - end)
        # 前向传播
        features = model(imgs)
        outputs = classifier(features)
        _, preds = torch.max(outputs.data, 1)

        # 计算损失
        cla_loss = criterion_cla(outputs, pids)
        pair_loss = criterion_pair(features, pids)

        if epoch >= config.TRAIN.START_EPOCH_ADV:
            adv_loss = criterion_adv(features, clothes_ids, pos_mask)
            loss = cla_loss + adv_loss + config.LOSS.PAIR_LOSS_WEIGHT * pair_loss
        else:
            loss = cla_loss + config.LOSS.PAIR_LOSS_WEIGHT * pair_loss

        optimizer.zero_grad()
        if config.TRAIN.AMP:
            with amp.scale_loss(loss, optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            loss.backward()
        optimizer.step()

        # 在训练循环中添加
        if epoch > 50:  # 后期训练添加更强的正则化
            # 添加特征dropout
            original_feats = F.dropout(original_feats, p=0.1, training=True)
            recon_feats = F.dropout(recon_feats, p=0.1, training=True)
            
            # 添加标签平滑
            if hasattr(criterion_cla, 'epsilon'):
                criterion_cla.epsilon = 0.1

        # 统计
        corrects.update(torch.sum(preds == pids.data).float() / pids.size(0), pids.size(0))
        batch_cla_loss.update(cla_loss.item(), pids.size(0))
        batch_pair_loss.update(pair_loss.item(), pids.size(0))
        if epoch >= config.TRAIN.START_EPOCH_ADV:
            batch_adv_loss.update(adv_loss.item(), clothes_ids.size(0))
        # 测量耗时
        batch_time.update(time.time() - end)
        end = time.time()

    logger.info('Epoch{0} '
                'Time:{batch_time.sum:.1f}s '
                'Data:{data_time.sum:.1f}s '
                'ClaLoss:{cla_loss.avg:.4f} '
                'PairLoss:{pair_loss.avg:.4f} '
                'AdvLoss:{adv_loss.avg:.4f} '
                'Acc:{acc.avg:.2%} '.format(
        epoch + 1,
        batch_time=batch_time,
        data_time=data_time,
        cla_loss=batch_cla_loss,
        pair_loss=batch_pair_loss,
        adv_loss=batch_adv_loss,
        acc=corrects
    ))


