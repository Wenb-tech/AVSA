import torchvision
from torch import nn
from torch.nn import init
from models.utils import pooling
import torch
import torch.nn.functional as F
import random

class ResNet50(nn.Module):
    def __init__(self, config, **kwargs):
        super().__init__()

        resnet50 = torchvision.models.resnet50(pretrained=True)
        if config.MODEL.RES4_STRIDE == 1:
            resnet50.layer4[0].conv2.stride=(1, 1)
            resnet50.layer4[0].downsample[0].stride=(1, 1) 
        self.base = nn.Sequential(*list(resnet50.children())[:-2])

        if config.MODEL.POOLING.NAME == 'avg':
            self.globalpooling = nn.AdaptiveAvgPool2d(1)
        elif config.MODEL.POOLING.NAME == 'max':
            self.globalpooling = nn.AdaptiveMaxPool2d(1)
        elif config.MODEL.POOLING.NAME == 'gem':
            self.globalpooling = pooling.GeMPooling(p=config.MODEL.POOLING.P)
        elif config.MODEL.POOLING.NAME == 'maxavg':
            self.globalpooling = pooling.MaxAvgPooling()
        else:
            raise KeyError("Invalid pooling: '{}'".format(config.MODEL.POOLING.NAME))

        self.bn = nn.BatchNorm1d(config.MODEL.FEATURE_DIM)
        init.normal_(self.bn.weight.data, 1.0, 0.02)
        init.constant_(self.bn.bias.data, 0.0)
        
    def forward(self, x): 
        x = self.base(x)
        x = self.globalpooling(x)
        x = x.view(x.size(0), -1)
        f = self.bn(x)

        return f


class FeatAug(nn.Module):
    def __init__(self, feature_dim, probability):
        super(FeatAug, self).__init__()
        self.probability = probability
        self.feature_dim = feature_dim
        
        
        self.transform_net = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.BatchNorm1d(feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, feature_dim),
            nn.BatchNorm1d(feature_dim)
        )
        
    def channel_shuffle(self, x):
        
        if random.random() < self.probability:
            batch_size, num_channels = x.size()
            indices = torch.randperm(num_channels)
            return x[:, indices]
        return x
    
    def feature_dropout(self, x):
        
        if random.random() < self.probability:
            mask = torch.ones_like(x)
            drop_idx = torch.randperm(self.feature_dim)[:int(self.feature_dim * 0.1)]
            mask[:, drop_idx] = 0
            return x * mask
        return x
    
    def feature_noise(self, x):
        
        if random.random() < self.probability:
            noise = torch.randn_like(x) * 0.05
            return x + noise
        return x
    
    def forward(self, original_feats, vib_generated_feats):
        
        aug_original = self.transform_net(original_feats)
        aug_original = self.channel_shuffle(aug_original)
        aug_original = self.feature_dropout(aug_original)
        aug_original = self.feature_noise(aug_original)
        
        
        aug_vib = self.channel_shuffle(vib_generated_feats)
        aug_vib = self.feature_dropout(aug_vib)
        aug_vib = self.feature_noise(aug_vib)
        
        return F.normalize(aug_original, p=2, dim=1), F.normalize(aug_vib, p=2, dim=1)

