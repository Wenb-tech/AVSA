import logging
from models.classifier import Classifier, NormalizedClassifier
from models.img_resnet import ResNet50
from models.vid_resnet import C2DResNet50, I3DResNet50, AP3DResNet50, NLResNet50, AP3DNLResNet50, FeatAug
from models.my.vib import VIB

__factory = {
    'resnet50': ResNet50,
    'c2dres50': C2DResNet50,
    'i3dres50': I3DResNet50,
    'ap3dres50': AP3DResNet50,
    'nlres50': NLResNet50,
    'ap3dnlres50': AP3DNLResNet50,
}

logger = logging.getLogger('reid.model')

def build_model(config, num_identities, num_clothes):
    # Build backbone
    logger.info("Initializing model: {}".format(config.MODEL.NAME))
    if config.MODEL.NAME not in __factory.keys():
        raise KeyError("Invalid model: '{}'".format(config.MODEL.NAME))
    else:
        logger.info("Init model: '{}'".format(config.MODEL.NAME))
        model = __factory[config.MODEL.NAME](config)
    logger.info("Model size: {:.5f}M".format(sum(p.numel() for p in model.parameters()) / 1000000.0))

    # Build VIB as domain augmentation
    feature_dim = config.MODEL.FEATURE_DIM
    latent_dim = getattr(config.VIB, 'LATENT_DIM', 128)
    vib = VIB(input_dim=feature_dim, latent_dim=latent_dim, output_dim=feature_dim)

    # Build classifier
    if config.LOSS.CLA_LOSS in ['crossentropy', 'crossentropylabelsmooth']:
        identity_classifier = Classifier(feature_dim=feature_dim, num_classes=num_identities)
    else:
        identity_classifier = NormalizedClassifier(feature_dim=feature_dim, num_classes=num_identities)

    clothes_classifier = NormalizedClassifier(feature_dim=feature_dim, num_classes=num_clothes)

    # Build FeatAug
    feat_aug = FeatAug(feature_dim=feature_dim, probability=getattr(config, 'probability', 0.8))

    return model, vib, feat_aug, identity_classifier, clothes_classifier