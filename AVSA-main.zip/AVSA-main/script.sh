
# For LTCC dataset
# python -m torch.distributed.run --nproc_per_node=3 --master_port 12345 main.py --dataset ltcc --cfg configs/aug.yaml --gpu 1,2,3 
# For PRCC dataset
#python -m torch.distributed.run --nproc_per_node=3 --master_port 12345 main.py --dataset prcc --cfg configs/aug.yaml --gpu 1,2,3 #
#For VC-Clothes dataset. You should change the root path of '--resume' to your output path.
# python -m torch.distributed.run --nproc_per_node=3 --master_port 8888 main.py --dataset vcclothes --cfg configs/aug.yaml --gpu 1,2,3
# For DeepChange dataset. Using amp can accelerate training.
#python -m torch.distributed.launch --nproc_per_node=3 --master_port 12345 main.py --dataset deepchange --cfg configs/aug.yaml  --gpu 0,1,2 #
